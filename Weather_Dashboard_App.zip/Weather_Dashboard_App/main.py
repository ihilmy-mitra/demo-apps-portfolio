from quote import get_quote
from weather import get_weather

def main():
    city = input("Enter city: ").strip()

    weather, weather_error = get_weather(city)
    quote, author = get_quote()

    print("\n=== Weather & Motivation Dashboard ===")

    if weather_error:
        print(weather_error)
    else:
        print(f"\nCity: {weather['city']}")
        print(f"Temperature: {weather['temp']}°C")
        print(f"Condition: {weather['condition']}")

    if quote:
        print(f'\n"{quote}"')
        print(f"- {author}")

if __name__ == "__main__":
    main()