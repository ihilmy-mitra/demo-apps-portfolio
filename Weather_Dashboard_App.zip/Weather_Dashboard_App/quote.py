import requests

ZEN_QUOTES_API = "https://zenquotes.io/api/random"

def get_quote():
    try:
        response = requests.get(ZEN_QUOTES_API, timeout=5)
        response.raise_for_status()
        data = response.json()

        return data[0]["q"], data[0]["a"]

    except requests.RequestException as e:
        return None, f"Quote Error: {e}"