import pandas as pd
import numpy as np

FILE_NAME = "sales_data.csv"

df = pd.read_csv(FILE_NAME)

print("\n Data Loaded Successfully")
print("Columns in dataset:")
print(df.columns)
print("\nFirst 5 rows:")
print(df.head())

df['revenue'] = df['Quantity_Sold'] * df['Unit_Price']
total_revenue = df['revenue'].sum()

print("\n Revenue Statistics:")
print("Mean Revenue:", df["revenue"].mean())
print("Median Revenue:", df["revenue"].median())
print("Standard Deviation:", df["revenue"].std())

top_products = (
    df.groupby("Product_ID")["revenue"]
    .sum()
    .sort_values(ascending=False)
)

print("\n Revenue by Product:")
print(top_products)

print("\n========== SALES INSIGHTS REPORT ==========")
print("Total Revenue:", total_revenue)

print("\nTop Products:")
print(top_products.head(3))