from bank_account import BankAccount

class CreditAccount(BankAccount):
    def __init__(self, account_number, holder_name, pin, balance=0, credit_limit=5000):
        super().__init__(account_number, holder_name, pin, balance)
        self.credit_limit = credit_limit

    def withdraw(self, amount):
        if self._balance - amount >= -self.credit_limit:
            self._balance -= amount
            return f"Credit Withdrawn: {amount}"
        return "Credit limit exceeded"

