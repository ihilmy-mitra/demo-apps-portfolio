class BankAccount:
    bank_name = "Smart Bank"

    def __init__(self, account_number, holder_name, pin, balance=0):
        self.account_number = account_number
        self.holder_name = holder_name
        self.__pin = pin          
        self._balance = balance

    def deposit(self, amount):
        if self.is_valid_amount(amount):
            self._balance += amount
            return f"Deposited: {amount}"
        return "Invalid deposit amount"

    def withdraw(self, amount):
        if amount <= self._balance:
            self._balance -= amount
            return f"Withdrawn: {amount}"
        return "Insufficient balance"

    def get_balance(self):
        return self._balance

    def check_pin(self, pin):
        return pin == self.__pin

    def change_pin(self, old_pin, new_pin):
        if self.check_pin(old_pin):
            self.__pin = new_pin
            return "PIN changed successfully"
        return "Incorrect old PIN"

    def __str__(self):
        return f"Account: {self.account_number} | Holder: {self.holder_name} | Balance: {self._balance}"

    @classmethod
    def get_bank_name(cls):
        return cls.bank_name

    @staticmethod
    def is_valid_amount(amount):
        return amount > 0
