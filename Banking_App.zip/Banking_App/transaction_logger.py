
def log_transaction(message):
    with open("transactions.txt", "a") as file:
        file.write(message + "\n")
