from savings_account import SavingsAccount
from credit_account import CreditAccount
from transaction_logger import log_transaction


def get_valid_choice():
    while True:
        choice = input("Enter your choice (1-8): ")
        if choice in [str(i) for i in range(1, 9)]:
            return choice
        print("Invalid choice. Please enter a number between 1 and 8.")


def get_valid_pin():
    while True:
        pin = input("Enter 4-digit PIN: ")
        if pin.isdigit() and len(pin) == 4:
            return pin
        print("PIN must be exactly 4 digits.")


def get_valid_amount(message):
    while True:
        try:
            amount = float(input(message))
            if amount > 0:
                return amount
            print("Amount must be greater than 0.")
        except ValueError:
            print("Please enter a valid number.")


def get_valid_name():
    while True:
        name = input("Enter Holder Name: ").strip()
        if name.replace(" ", "").isalpha():
            return name
        print("Name must contain only letters.")


def get_unique_account(accounts):
    while True:
        acc_no = input("Enter Account Number: ").strip()
        if not acc_no:
            print("Account number cannot be empty.")
            continue
        if any(a.account_number == acc_no for a in accounts):
            print("Account number already exists.")
            continue
        return acc_no


def find_account(accounts, acc_no):
    return next((a for a in accounts if a.account_number == acc_no), None)



def main():
    accounts = []
    print("\n🏦 Welcome to Smart Bank Banking System 🏦")

    while True:
        print("""
Menu:
1. Create Savings Account
2. Create Credit Account
3. Deposit
4. Withdraw
5. Check Balance
6. Add Interest (Savings Only)
7. Change PIN
8. Exit
""")

        choice = get_valid_choice()

        if choice == "1":
            acc_no = get_unique_account(accounts)
            name = get_valid_name()
            pin = get_valid_pin()
            balance = get_valid_amount("Initial Deposit: ")

            account = SavingsAccount(acc_no, name, pin, balance)
            accounts.append(account)

            print("✅ Savings Account created successfully!")
            log_transaction(f"Savings Account {acc_no} created with balance {balance}")

        elif choice == "2":
            acc_no = get_unique_account(accounts)
            name = get_valid_name()
            pin = get_valid_pin()
            balance = get_valid_amount("Initial Deposit: ")
            credit_limit = get_valid_amount("Set Credit Limit: ")

            account = CreditAccount(acc_no, name, pin, balance, credit_limit)
            accounts.append(account)

            print("✅ Credit Account created successfully!")
            log_transaction(f"Credit Account {acc_no} created with limit {credit_limit}")

        elif choice in ["3", "4", "5", "6", "7"]:
            acc_no = input("Enter Account Number: ").strip()
            account = find_account(accounts, acc_no)

            if not account:
                print("❌ Account not found.")
                continue

            pin = get_valid_pin()
            if not account.check_pin(pin):
                print("❌ Incorrect PIN.")
                continue

            if choice == "3":
                amount = get_valid_amount("Enter deposit amount: ")
                print(account.deposit(amount))
                log_transaction(f"{acc_no} Deposited {amount}")

            elif choice == "4":
                amount = get_valid_amount("Enter withdrawal amount: ")
                print(account.withdraw(amount))
                log_transaction(f"{acc_no} Withdrawn {amount}")

            elif choice == "5":
                print(f"💰 Current Balance: {account.get_balance()}")

            elif choice == "6":
                if isinstance(account, SavingsAccount):
                    print(account.add_interest())
                    log_transaction(f"{acc_no} Interest added")
                else:
                    print("❌ Interest applies only to Savings Accounts.")

            elif choice == "7":
                old_pin = get_valid_pin()
                new_pin = get_valid_pin()
                print(account.change_pin(old_pin, new_pin))
                log_transaction(f"{acc_no} PIN changed")

        elif choice == "8":
            print("👋 Thank you for using Smart Bank!")
            break


if __name__ == "__main__":
    main()
