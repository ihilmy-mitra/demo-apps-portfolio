from bank_account import BankAccount

class SavingsAccount(BankAccount):
    def __init__(self, account_number, holder_name, pin, balance=0, interest_rate=0.03):
        super().__init__(account_number, holder_name, pin, balance)
        self.interest_rate = interest_rate

    def add_interest(self):
        interest = self._balance * self.interest_rate
        self._balance += interest
        return f"Interest added: {interest}"
