import csv
import json
import os
from collections import Counter
import pandas as pd

CSV_FILE = "expenses.csv"
JSON_FILE = "summary.json"

def create_csv():
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["name", "category", "amount"])


def add_expense():
    try:
        name = input("Enter Expense name: ").strip()

        if not name:
            raise ValueError("Expense name cannot be empty")

        if name.isdigit():
            raise ValueError("Expense name must contain letters, not only numbers")

        category = input("Enter category: ").strip()

        if not category:
            raise ValueError("Category cannot be empty")

        if category.isdigit():
            raise ValueError("Category must contain letters, not only numbers")

        amount_input = input("Enter amount: ")
        amount = float(amount_input)

        if amount <= 0:
            raise ValueError("Amount must be greater than 0")

        with open(CSV_FILE, mode="a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([name, category, amount])

        print("Expense added successfully")

    except ValueError as e:
        print(f"Invalid input: {e}")

    except Exception as e:
        print(f"Unexpected error: {e}")
        
        
def summarize_expenses():
    
    if not os.path.exists(CSV_FILE):
        print("Error: expenses.csv file not found.")
        return

    try:
        df = pd.read_csv(CSV_FILE)

        required_columns = {"category", "amount"}
        if not required_columns.issubset(df.columns):
            print("Error: CSV file must contain 'category' and 'amount' columns.")
            return

        df["amount"] = pd.to_numeric(df["amount"], errors="coerce")

        df = df.dropna(subset=["amount", "category"])

        summary = df.groupby("category")["amount"].sum()

        summary.to_json(JSON_FILE, indent=4)
        
        print("\nSummary by Category:")
        for category, total in summary.items():
            print(f"{category}: {total:.2f}")

        print("\nSaved to summary.json")

    except Exception as e:
        print("Unexpected error:", e)



def main():
    create_csv()

    while True:
        print("\n--- Simple Expense Tracker ---")
        print("1. Add Expense")
        print("2. View Summary")
        print("3. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            add_expense()
        elif choice == "2":
            summarize_expenses()
        elif choice == "3":
            print("Thank You For choosing!")
            break
        else:
            print("Invalid option")

if __name__ == "__main__":
    main()