from pathlib import Path
import smtplib
from email.message import EmailMessage

REPORTS_DIR = Path("C:/Users/ihilmy/Desktop/DataFolderAnalyzer/reports")
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

SENDER_EMAIL = "ihilmy@mitrai.com"
APP_PASSWORD = "almx jrro ccom jius"
RECEIVER_EMAIL = "ilhamhilmy434@gmail.com"


SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465


REPORTS_DIR = Path("C:/Users/ihilmy/Desktop/DataFolderAnalyzer/reports")
REPORTS_DIR.mkdir(parents=True, exist_ok=True)


def analyze_folder(folder_path):
    summary = {}
    total_files = 0
    total_size = 0

    for file in folder_path.rglob("*"):
        if file.is_file():
            total_files += 1
            size = file.stat().st_size
            total_size += size

            extension = file.suffix.lower()
            if extension == "":
                extension = "NO_EXTENSION"

            if extension not in summary:
                summary[extension] = {"count": 0, "size": 0}

            summary[extension]["count"] += 1
            summary[extension]["size"] += size

    return summary, total_files, total_size


def generate_report(summary, total_files, total_size):
    report_file = REPORTS_DIR / "report.txt"

    with open(report_file, "w", encoding="utf-8") as report:
        report.write("DATA FOLDER ANALYSIS REPORT\n")
        report.write("===========================\n\n")

        report.write(f"Total Files Scanned: {total_files}\n")
        report.write(f"Total Size: {total_size / 1024:.2f} KB\n\n")

        report.write("File Type Summary:\n")
        report.write("-------------------\n")

        for ext, data in summary.items():
            report.write(
                f"{ext} -> Files: {data['count']}, "
                f"Size: {data['size'] / 1024:.2f} KB\n"
            )

    return report_file


def send_email(report_path):
    msg = EmailMessage()
    msg["Subject"] = "Data Folder Analysis Report"
    msg["From"] = SENDER_EMAIL
    msg["To"] = RECEIVER_EMAIL

    with open(report_path, "r", encoding="utf-8") as file:
        msg.set_content(file.read())

    try:
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT) as server:
            server.login(SENDER_EMAIL, APP_PASSWORD)
            server.send_message(msg)
        print("📧 Email sent successfully!")
    except Exception as e:
        print("❌ Email failed!")
        print(e)


def main():
    print("DATA FOLDER ANALYZER")
    print("----------------------")

    folder_input = input("Enter the FULL folder path to analyze: ").strip()
    folder_path = Path(folder_input)

    if not folder_path.exists():
        print("Folder does not exist!")
        return

    if not folder_path.is_dir():
        print("This path is not a folder!")
        return

    summary, total_files, total_size = analyze_folder(folder_path)
    report_path = generate_report(summary, total_files, total_size)

    print("\nAnalysis completed successfully!")
    print(f"Report saved at:\n{report_path}")

    # ASK USER FOR EMAIL
    choice = input("\nDo you want to email the report? (yes/no): ").lower()
    if choice == "yes":
        send_email(report_path)


if __name__ == "__main__":
    main()
