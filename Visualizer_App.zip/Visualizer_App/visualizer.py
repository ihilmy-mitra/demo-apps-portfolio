import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


CSV_FILE = "expenses.csv"
CHARTS_FOLDER = "charts"

os.makedirs(CHARTS_FOLDER, exist_ok=True)
sns.set(style="whitegrid")

df = pd.read_csv(CSV_FILE)
print("Data Loaded Successfully")
print(df.head())

category_summary = df.groupby("category")["amount"].sum().reset_index()

print("\nCategory-wise Spending:")
print(category_summary)

plt.figure()
sns.barplot(
    data=category_summary,
    x="category",
    y="amount"
)

plt.title("Total Spending by Category")
plt.xlabel("Category")
plt.ylabel("Amount")
plt.xticks(rotation=30)

bar_chart_path = os.path.join(CHARTS_FOLDER, "category_spending_bar.png")
plt.tight_layout()
plt.savefig(bar_chart_path)
plt.close()

print(f"Bar chart saved to {bar_chart_path}")

plt.figure()
plt.pie(
    category_summary["amount"],
    labels=category_summary["category"],
    autopct="%1.1f%%",
    startangle=140
)

plt.title("Expense Distribution by Category")

pie_chart_path = os.path.join(CHARTS_FOLDER, "category_spending_pie.png")
plt.tight_layout()
plt.savefig(pie_chart_path)
plt.close()

print(f"Pie chart saved to {pie_chart_path}")

print("\nExpense Visualization Completed Successfully!")